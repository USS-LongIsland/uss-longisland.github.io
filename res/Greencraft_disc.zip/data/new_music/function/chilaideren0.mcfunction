#give ChiLaiDeRen to player
give @s minecraft:music_disc_13[minecraft:jukebox_playable="new_music:chilaideren0",minecraft:custom_model_data={strings:["chilaideren0"]}]