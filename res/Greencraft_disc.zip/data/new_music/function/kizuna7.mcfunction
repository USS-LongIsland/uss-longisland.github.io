#give KIZUNA to player
give @s minecraft:music_disc_13[minecraft:jukebox_playable="new_music:kizuna7",minecraft:custom_model_data={strings:["kizuna7"]}]