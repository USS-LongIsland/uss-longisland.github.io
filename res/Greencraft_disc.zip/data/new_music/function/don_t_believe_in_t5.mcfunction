#give Don't Believe in T to player
give @s minecraft:music_disc_13[minecraft:jukebox_playable="new_music:don_t_believe_in_t5",minecraft:custom_model_data={strings:["don_t_believe_in_t5"]}]