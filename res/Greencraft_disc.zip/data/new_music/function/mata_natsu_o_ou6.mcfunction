#give Mata Natsu o Ou to player
give @s minecraft:music_disc_13[minecraft:jukebox_playable="new_music:mata_natsu_o_ou6",minecraft:custom_model_data={strings:["mata_natsu_o_ou6"]}]