#give HaiDi to player
give @s minecraft:music_disc_13[minecraft:jukebox_playable="new_music:haidi1",minecraft:custom_model_data={strings:["haidi1"]}]