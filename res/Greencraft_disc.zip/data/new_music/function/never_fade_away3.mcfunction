#give Never Fade Away to player
give @s minecraft:music_disc_13[minecraft:jukebox_playable="new_music:never_fade_away3",minecraft:custom_model_data={strings:["never_fade_away3"]}]